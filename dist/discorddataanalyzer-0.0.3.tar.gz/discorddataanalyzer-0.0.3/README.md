# Discord-Data-Python-Module
A Python Module to make reading your Discord Data Package a simpler task.
